SMTP_USER=francis.glavieux@gmail.com
SMTP_PASS="jfnj dtxa xyfc"
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=tls
SMTP_TO=glavieux.francis@free.fr
